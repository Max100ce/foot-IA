let poids1 = open_out_bin "poids-bias/poids1" and
    poids2 = open_out_bin "poids-bias/poids2" and
    poids3 = open_out_bin "poids-bias/poids3" and
    bias1 = open_out_bin "poids-bias/bias1" and
    bias2 = open_out_bin "poids-bias/bias2" and
    bias3 = open_out_bin "poids-bias/bias3" in

print_string "Choisissez la seed : ";
let seed = read_int () in    
Random.init seed;
    
for i = 0 to 50 do
  for j = 0 to 15 do
    output_value poids1 (((float_of_int (Random.int 10000)) /. 5000.) -. 1.);
  done;
done;

for i = 0 to 15 do
  output_value bias1 (((float_of_int (Random.int 10000)) /. 5000.) -. 1.);
  for j = 0 to 15 do
    output_value poids2 (((float_of_int (Random.int 10000)) /. 5000.) -. 1.);
  done;
done;

for i = 0 to 15 do
  output_value bias2 (((float_of_int (Random.int 10000)) /. 5000.) -. 1.);
  for j = 0 to 2 do
    output_value poids3 (((float_of_int (Random.int 10000)) /. 5000.) -. 1.);
  done;
done;

for i = 0 to 2 do
  output_value bias3 (((float_of_int (Random.int 10000)) /. 5000.) -. 1.);
done;

close_out poids1;
close_out poids2;
close_out poids3;
close_out bias1;
close_out bias2;
close_out bias3;
