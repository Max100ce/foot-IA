module type Calcul_S =
  sig
    val transposee : int * int -> float array array -> float array array
    val prod_mat : int * int -> int * int -> float array array -> float array array -> float array array
    val add_mat : int * int -> int * int -> float array array -> float array array -> float array array
    val mult_mat : int * int -> int * int -> float array array -> float array array -> float array array
    val sous_mat : int * int -> int * int -> float array array -> float array array -> float array array
    val scalaire : int * int -> float array array -> float -> float array array
    val normalize : int * int -> float array array -> float array array
    val d_normalize : int * int -> float array array -> float array array
    val d_cost : int * int -> int * int -> float array array -> float array array -> float array array
    val pos_max : int * int -> float array array -> int * int
    val compare : int * int -> float array array -> int * int -> bool
  end

module Calcul : Calcul_S =
  struct
    let transposee (nA, mA) matA =
      let matB = Array.make_matrix mA nA 0. in
      for i = 0 to mA - 1 do
        for j = 0 to nA - 1 do
          matB.(i).(j) <- matA.(j).(i);
        done;
      done;
      matB
    
    let prod_mat (nA, mA) (nB, mB) matA matB =
      if mA <> nB then failwith "erreur de dimension (prod)";
      let matC = Array.make_matrix nA mB 0. in
      for i = 0 to nA - 1 do
        for j = 0 to mB - 1 do
          for k = 0 to mA - 1 do
            matC.(i).(j) <- matC.(i).(j) +. matA.(i).(k) *. matB.(k).(j);
          done;
        done;
      done;
      matC

    let add_mat (nA, mA) (nB, mB) matA matB =
      if nA <> nB || mA <> mB then failwith "erreur de dimension (add)";
      let matC = Array.make_matrix nA mA 0. in
      for i = 0 to nA - 1 do
        for j = 0 to mA - 1 do
          matC.(i).(j) <- matA.(i).(j) +. matB.(i).(j);
        done;
      done;
      matC

    let mult_mat (nA, mA) (nB, mB) matA matB =
      if nA <> nB || mA <> mB then failwith "erreur de dimension (mult)";
      let matC = Array.make_matrix nA mA 0. in
      for i = 0 to nA - 1 do
        for j = 0 to mA - 1 do
          matC.(i).(j) <- matA.(i).(j) *. matB.(i).(j);
        done;
      done;
      matC

    let sous_mat (nA, mA) (nB, mB) matA matB =
      if nA <> nB || mA <> mB then failwith "erreur de dimension (sous)";
      let matC = Array.make_matrix nA mA 0. in
      for i = 0 to nA - 1 do
        for j = 0 to mA - 1 do
          matC.(i).(j) <- matA.(i).(j) -. matB.(i).(j);
        done;
      done;
      matC

    let scalaire (nA, mA) matA lambda =
      let matB = Array.make_matrix nA mA 0. in
      for i = 0 to nA - 1 do
        for j = 0 to mA -1 do
          matB.(i).(j) <- matA.(i).(j) *. lambda;
        done;
      done;
      matB

    let normalize (nA, mA) matA =
      let matB = Array.make_matrix nA mA 0. in
      for i = 0 to nA - 1 do
        for j = 0 to mA - 1 do
          matB.(i).(j) <- 1. /. (1. +. exp(0. -. matA.(i).(j)));
        done;
      done;
      matB

    let d_normalize (nA, mA) matA =
      let matB = Array.make_matrix nA mA 0. in
      for i = 0 to nA - 1 do
        for j = 0 to mA - 1 do
          matB.(i).(j) <- exp (0. -. matA.(i).(j)) /. (Float.pow (1. +. exp (0. -. matA.(i).(j))) 2.);
        done;
      done;
      matB

    let d_cost (nA, mA) (nB, mB) matA matB =
      if nA <> nB || mA <> mB then failwith "erreur de dimension (d_cost)";
      let matC = Array.make_matrix nA mA 0. in
      for i = 0 to nA - 1 do
        for j = 0 to mA - 1 do
          matC.(i).(j) <- 2. *. (matA.(i).(j) -. matB.(i).(j));
        done;
      done;
      matC

    let pos_max (nA, mA) matA =
      let m = ref matA.(0).(0) in
      let pos = ref (0, 0) in
      for i = 0 to nA - 1 do
        for j = 0 to mA - 1 do
          if !m < matA.(i).(j) then (
            m := matA.(i).(j);
            pos := (i, j);
          );
        done;
      done;
      !pos

    let compare (nA, mA) matA (posN, posM) =
      if posN >= nA || posM >= mA then failwith "Cette position est impossible"
      else matA.(posN).(posM) = 1.
  end
    
