let arret_f = open_out "arret.txt" in
output_char arret_f 'a';
close_out arret_f;
