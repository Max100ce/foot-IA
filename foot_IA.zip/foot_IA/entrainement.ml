open Calcul;;

(* OUVERTURE *)
        
let entree_f = open_in "data/tous_les_matchs.txt" and
    labels_f = open_in "data/tous_les_resultats.txt" and
    nbMatch_f = open_in "data/nbMatchs.txt" in

let nbMatch = int_of_string (input_line nbMatch_f) in

let entree = Array.make nbMatch [||] and
    labels = Array.make nbMatch 0 in

let rec float_array_of_string_list sl n a =
  match sl with
  | s :: sl1 -> (
    a.((Array.length a) - n) <- float_of_string s;
    float_array_of_string_list sl1 (n-1) a
  )
  | [] -> a
in

for i = 0 to nbMatch - 1 do
  entree.(i) <- Array.make_matrix 1 51 0.;
  let string_liste = String.split_on_char ',' (input_line entree_f) in
  entree.(i).(0) <- float_array_of_string_list string_liste (List.length string_liste) (Array.make 51 0.);
  labels.(i) <- int_of_string (input_line labels_f)
done;

close_in entree_f;
close_in labels_f;
close_in nbMatch_f;

let poids1_f = open_in_bin "poids-bias/poids1" and
    poids2_f = open_in_bin "poids-bias/poids2" and
    poids3_f = open_in_bin "poids-bias/poids3" and
    bias1_f = open_in_bin "poids-bias/bias1" and
    bias2_f = open_in_bin "poids-bias/bias2" and
    bias3_f = open_in_bin "poids-bias/bias3" in

let poids1 = ref (Array.make 51 [||]) and
    poids2 = ref (Array.make 16 [||]) and
    poids3 = ref (Array.make 16 [||]) and
    bias1 = ref [|Array.make 16 0.|] and
    bias2 = ref [|Array.make 16 0.|] and
    bias3 = ref [|Array.make 3 0.|] in

for i = 0 to 50 do
  !poids1.(i) <- Array.make 16 0.;
  for j = 0 to 15 do
    !poids1.(i).(j) <- input_value poids1_f;
  done;
done;

for i = 0 to 15 do
  !bias1.(0).(i) <- input_value bias1_f;
  !poids2.(i) <- Array.make 16 0.;
  for j = 0 to 15 do
    !poids2.(i).(j) <- input_value poids2_f;
  done;
done;

for i = 0 to 15 do
  !bias2.(0).(i) <- input_value bias2_f;
  !poids3.(i) <- Array.make 16 0.;
  for j = 0 to 2 do
    !poids3.(i).(j) <- input_value poids3_f;
  done;
done;

for i = 0 to 2 do
  !bias3.(0).(i) <- input_value bias3_f;
done;

close_in poids1_f;
close_in poids2_f;
close_in poids3_f;
close_in bias1_f;
close_in bias2_f;
close_in bias3_f;

(* ALGORITHME *)

Random.init (int_of_float (Float.round (!poids1.(0).(0) *. 10000.)));

let arret_f = open_out "arret.txt" in
output_char arret_f 'c';
close_out arret_f;

let arret = ref 'c' in
let compteur = ref 0 in
while !arret = 'c' do
  compteur := !compteur + 1;
  let derivee_poids1 = ref (Array.make_matrix 51 16 0.) in
  let derivee_poids2 = ref (Array.make_matrix 16 16 0.) in
  let derivee_poids3 = ref (Array.make_matrix 16 3 0.) in
  let derivee_bias1 = ref [|Array.make 16 0.|] in
  let derivee_bias2 = ref [|Array.make 16 0.|] in
  let derivee_bias3 = ref [|Array.make 3 0.|] in

  let cout = ref 0. in
  let bon = ref 0 in
  
  for i = 0 to 999 do
    let numero = Random.int nbMatch in
    let cache_1_temp = Calcul.add_mat (1, 16) (1, 16) (Calcul.prod_mat (1, 51) (51, 16) entree.(numero) !poids1) !bias1 in
    let cache_1 = Calcul.normalize (1, 16) cache_1_temp in
    let cache_2_temp = Calcul.add_mat (1, 16) (1, 16) (Calcul.prod_mat (1, 16) (16, 16) cache_1 !poids2) !bias2 in
    let cache_2 = Calcul.normalize (1, 16) cache_2_temp in
    let sortie_temp = Calcul.add_mat (1, 3) (1, 3) (Calcul.prod_mat (1, 16) (16, 3) cache_2 !poids3) !bias3 in
    let sortie = Calcul.normalize (1, 3) sortie_temp in
    
    let voulu = [|Array.make 3 0.|] in
    voulu.(0).(labels.(numero)) <- 1.;

    for j = 0 to 2 do
      cout := !cout +. Float.pow (voulu.(0).(j) -. sortie.(0).(j)) 2.
    done;
    if sortie.(0).(0) > sortie.(0).(1) && sortie.(0).(0) > sortie.(0).(2) && labels.(numero) = 0 then
      bon := !bon + 1;
    if sortie.(0).(1) > sortie.(0).(0) && sortie.(0).(1) > sortie.(0).(2) && labels.(numero) = 1 then
      bon := !bon + 1;
    if sortie.(0).(2) > sortie.(0).(0) && sortie.(0).(2) > sortie.(0).(1) && labels.(numero) = 2 then
      bon := !bon + 1;
    
    let derivee_sortie_temp = Calcul.mult_mat (1, 3) (1, 3) (Calcul.d_normalize (1, 3) sortie_temp) (Calcul.d_cost (1, 3) (1, 3) sortie voulu) in
    derivee_bias3 := Calcul.sous_mat (1, 3) (1, 3) !derivee_bias3 derivee_sortie_temp;
    derivee_poids3 := Calcul.sous_mat (16, 3) (16, 3) !derivee_poids3 (Calcul.prod_mat (16, 1) (1, 3) (Calcul.transposee (1, 16) cache_2) derivee_sortie_temp);

    let derivee_cache_2_temp = Calcul.mult_mat (1, 16) (1, 16) (Calcul.d_normalize (1, 16) cache_2_temp) (Calcul.prod_mat (1, 3) (3, 16) derivee_sortie_temp (Calcul.transposee (16, 3) !poids3)) in

    derivee_bias2 := Calcul.sous_mat (1, 16) (1, 16) !derivee_bias2 derivee_cache_2_temp;
    derivee_poids2 := Calcul.sous_mat (16, 16) (16, 16) !derivee_poids2 (Calcul.prod_mat (16, 1) (1, 16) (Calcul.transposee (1, 16) cache_1) derivee_cache_2_temp);

    let derivee_cache_1_temp = Calcul.mult_mat (1, 16) (1, 16) (Calcul.d_normalize (1, 16) cache_1_temp) (Calcul.prod_mat (1, 16) (16, 16) derivee_cache_2_temp (Calcul.transposee (16, 16) !poids2)) in

    derivee_bias1 := Calcul.sous_mat (1, 16) (1, 16) !derivee_bias1 derivee_cache_1_temp;
    derivee_poids1 := Calcul.sous_mat (51, 16) (51, 16) !derivee_poids1 (Calcul.prod_mat (51, 1) (1, 16) (Calcul.transposee (1, 51) entree.(numero)) derivee_cache_1_temp);

  done;
  print_string "Itération numéro : ";
  print_int !compteur;
  print_string ", le coût total est de : ";
  print_float !cout;
  print_string ", le nombre de bon pari est de : ";
  print_int !bon;
  print_newline ();

  bias3 := Calcul.add_mat (1, 3) (1, 3) !bias3 (Calcul.scalaire (1, 3) !derivee_bias3 0.0001);
  poids3 := Calcul.add_mat (16, 3) (16, 3) !poids3 (Calcul.scalaire (16, 3) !derivee_poids3 0.0001);
  bias2 := Calcul.add_mat (1, 16) (1, 16) !bias2 (Calcul.scalaire (1, 16) !derivee_bias2 0.0001);
  poids2 := Calcul.add_mat (16, 16) (16, 16) !poids2 (Calcul.scalaire (16, 16) !derivee_poids2 0.0001);
  bias1 := Calcul.add_mat (1, 16) (1, 16) !bias1 (Calcul.scalaire (1, 16) !derivee_bias1 0.0001);
  poids1 := Calcul.add_mat (51, 16) (51, 16) !poids1 (Calcul.scalaire (51, 16) !derivee_poids1 0.0001);
  
  let arret_f = open_in "arret.txt" in
  arret := input_char arret_f;
  close_in arret_f
done;

let poids1_f = open_out_bin "poids-bias/poids1" and
    poids2_f = open_out_bin "poids-bias/poids2" and
    poids3_f = open_out_bin "poids-bias/poids3" and
    bias1_f = open_out_bin "poids-bias/bias1" and
    bias2_f = open_out_bin "poids-bias/bias2" and
    bias3_f = open_out_bin "poids-bias/bias3" in
    
for i = 0 to 50 do
  for j = 0 to 15 do
    output_value poids1_f !poids1.(i).(j);
  done;
done;

for i = 0 to 15 do
  output_value bias1_f !bias1.(0).(i);
  for j = 0 to 15 do
    output_value poids2_f !poids2.(i).(j);
  done;
done;

for i = 0 to 15 do
  output_value bias2_f !bias2.(0).(i);
  for j = 0 to 2 do
    output_value poids3_f !poids3.(i).(j);
  done;
done;

for i = 0 to 2 do
  output_value bias3_f !bias3.(0).(i);
done;

close_out poids1_f;
close_out poids2_f;
close_out poids3_f;
close_out bias1_f;
close_out bias2_f;
close_out bias3_f;
