set -ev

ocamlc -c calcul.ml
ocamlc -o entrainement calcul.cmo entrainement.ml
ocamlc -o initialisation initialisation.ml
ocamlc -o sauvegarde sauvegarde.ml

rm *cm*
