import requests
from bs4 import BeautifulSoup
from tqdm import *
from math import exp

# SAISON

listePays = ["https://www.mondefootball.fr/toutes_les_jeux/fra-ligue-1-1961-1962/", "https://www.mondefootball.fr/toutes_les_jeux/bundesliga-1963-1964/", "https://www.mondefootball.fr/toutes_les_jeux/eng-premier-league-1957-1958/", "https://www.mondefootball.fr/toutes_les_jeux/ita-serie-a-1950-1951/", "https://www.mondefootball.fr/toutes_les_jeux/esp-primera-division-1945-1946/", "https://www.mondefootball.fr/toutes_les_jeux/ned-eredivisie-1956-1957/", "https://www.mondefootball.fr/toutes_les_jeux/por-primeira-liga-1987-1988/"]
listeSaison = []
for pays in listePays:
	for i in range(int(pays[-10:-6]), 2023):
		if i != 2019 and i != 2020:
			listeSaison.append(pays[:-10] + str(i) + '-' + str(i + 1) + '/')

listeSaison.remove("https://www.mondefootball.fr/toutes_les_jeux/fra-ligue-1-1981-1982/")
listeSaison.remove("https://www.mondefootball.fr/toutes_les_jeux/fra-ligue-1-1986-1987/")
listeSaison.remove("https://www.mondefootball.fr/toutes_les_jeux/fra-ligue-1-1988-1989/")
listeSaison.remove("https://www.mondefootball.fr/toutes_les_jeux/fra-ligue-1-1990-1991/")
listeSaison.remove("https://www.mondefootball.fr/toutes_les_jeux/bundesliga-1966-1967/")
listeSaison.remove("https://www.mondefootball.fr/toutes_les_jeux/bundesliga-1967-1968/")
listeSaison.remove("https://www.mondefootball.fr/toutes_les_jeux/bundesliga-1983-1984/")
listeSaison.remove("https://www.mondefootball.fr/toutes_les_jeux/eng-premier-league-1987-1988/")
listeSaison.remove("https://www.mondefootball.fr/toutes_les_jeux/eng-premier-league-1993-1994/")
listeSaison.remove("https://www.mondefootball.fr/toutes_les_jeux/eng-premier-league-1997-1998/")
listeSaison.remove("https://www.mondefootball.fr/toutes_les_jeux/ita-serie-a-1951-1952/")
listeSaison.remove("https://www.mondefootball.fr/toutes_les_jeux/ita-serie-a-1952-1953/")
listeSaison.remove("https://www.mondefootball.fr/toutes_les_jeux/ita-serie-a-1953-1954/")
listeSaison.remove("https://www.mondefootball.fr/toutes_les_jeux/ita-serie-a-1954-1955/")
listeSaison.remove("https://www.mondefootball.fr/toutes_les_jeux/ita-serie-a-1959-1960/")
listeSaison.remove("https://www.mondefootball.fr/toutes_les_jeux/ita-serie-a-1961-1962/")
listeSaison.remove("https://www.mondefootball.fr/toutes_les_jeux/ita-serie-a-1962-1963/")
listeSaison.remove("https://www.mondefootball.fr/toutes_les_jeux/ita-serie-a-1963-1964/")
listeSaison.remove("https://www.mondefootball.fr/toutes_les_jeux/ita-serie-a-1966-1967/")
listeSaison.remove("https://www.mondefootball.fr/toutes_les_jeux/ita-serie-a-1967-1968/")
listeSaison.remove("https://www.mondefootball.fr/toutes_les_jeux/ita-serie-a-1968-1969/")
listeSaison.remove("https://www.mondefootball.fr/toutes_les_jeux/ita-serie-a-1969-1970/")
listeSaison.remove("https://www.mondefootball.fr/toutes_les_jeux/ita-serie-a-1970-1971/")
listeSaison.remove("https://www.mondefootball.fr/toutes_les_jeux/ita-serie-a-1972-1973/")
listeSaison.remove("https://www.mondefootball.fr/toutes_les_jeux/ita-serie-a-1974-1975/")
listeSaison.remove("https://www.mondefootball.fr/toutes_les_jeux/ita-serie-a-1975-1976/")
listeSaison.remove("https://www.mondefootball.fr/toutes_les_jeux/ita-serie-a-1976-1977/")
listeSaison.remove("https://www.mondefootball.fr/toutes_les_jeux/ita-serie-a-1977-1978/")
listeSaison.remove("https://www.mondefootball.fr/toutes_les_jeux/ita-serie-a-1978-1979/")
listeSaison.remove("https://www.mondefootball.fr/toutes_les_jeux/ita-serie-a-1982-1983/")
listeSaison.remove("https://www.mondefootball.fr/toutes_les_jeux/ita-serie-a-1987-1988/")
listeSaison.remove("https://www.mondefootball.fr/toutes_les_jeux/ita-serie-a-1989-1990/")
listeSaison.remove("https://www.mondefootball.fr/toutes_les_jeux/ita-serie-a-2005-2006/")
listeSaison.remove("https://www.mondefootball.fr/toutes_les_jeux/ita-serie-a-2012-2013/")
listeSaison.remove("https://www.mondefootball.fr/toutes_les_jeux/ita-serie-a-2016-2017/")
listeSaison.remove("https://www.mondefootball.fr/toutes_les_jeux/esp-primera-division-1946-1947/")
listeSaison.remove("https://www.mondefootball.fr/toutes_les_jeux/esp-primera-division-1979-1980/")
listeSaison.remove("https://www.mondefootball.fr/toutes_les_jeux/esp-primera-division-1986-1987/")
listeSaison.remove("https://www.mondefootball.fr/toutes_les_jeux/esp-primera-division-2016-2017/")
listeSaison.remove("https://www.mondefootball.fr/toutes_les_jeux/ned-eredivisie-1992-1993/")
listeSaison.remove("https://www.mondefootball.fr/toutes_les_jeux/ned-eredivisie-1994-1995/")
listeSaison.remove("https://www.mondefootball.fr/toutes_les_jeux/ned-eredivisie-1995-1996/")
listeSaison.remove("https://www.mondefootball.fr/toutes_les_jeux/ned-eredivisie-1996-1997/")
listeSaison.remove("https://www.mondefootball.fr/toutes_les_jeux/ned-eredivisie-1997-1998/")
listeSaison.remove("https://www.mondefootball.fr/toutes_les_jeux/ned-eredivisie-1998-1999/")
listeSaison.remove("https://www.mondefootball.fr/toutes_les_jeux/ned-eredivisie-1999-2000/")
listeSaison.remove("https://www.mondefootball.fr/toutes_les_jeux/ned-eredivisie-2000-2001/")
listeSaison.remove("https://www.mondefootball.fr/toutes_les_jeux/ned-eredivisie-2001-2002/")
listeSaison.remove("https://www.mondefootball.fr/toutes_les_jeux/ned-eredivisie-2002-2003/")
listeSaison.remove("https://www.mondefootball.fr/toutes_les_jeux/ned-eredivisie-2003-2004/")
listeSaison.remove("https://www.mondefootball.fr/toutes_les_jeux/ned-eredivisie-2004-2005/")
listeSaison.remove("https://www.mondefootball.fr/toutes_les_jeux/por-primeira-liga-2002-2003/")
listeSaison.remove("https://www.mondefootball.fr/toutes_les_jeux/por-primeira-liga-2003-2004/")
listeSaison.remove("https://www.mondefootball.fr/toutes_les_jeux/por-primeira-liga-2004-2005/")
listeSaison.remove("https://www.mondefootball.fr/toutes_les_jeux/por-primeira-liga-2005-2006/")
listeSaison.remove("https://www.mondefootball.fr/toutes_les_jeux/por-primeira-liga-2006-2007/")
listeSaison.remove("https://www.mondefootball.fr/toutes_les_jeux/por-primeira-liga-2007-2008/")
listeSaison.remove("https://www.mondefootball.fr/toutes_les_jeux/por-primeira-liga-2008-2009/")
listeSaison.remove("https://www.mondefootball.fr/toutes_les_jeux/por-primeira-liga-2009-2010/")
listeSaison.remove("https://www.mondefootball.fr/toutes_les_jeux/por-primeira-liga-2010-2011/")
listeSaison.remove("https://www.mondefootball.fr/toutes_les_jeux/por-primeira-liga-2011-2012/")
listeSaison.remove("https://www.mondefootball.fr/toutes_les_jeux/por-primeira-liga-2012-2013/")

listeSaison.append("https://www.mondefootball.fr/toutes_les_jeux/esp-primera-division-2016-2017_2/")
listeSaison.append("https://www.mondefootball.fr/toutes_les_jeux/por-superliga-2002-2003/")
listeSaison.append("https://www.mondefootball.fr/toutes_les_jeux/por-superliga-2003-2004/")
listeSaison.append("https://www.mondefootball.fr/toutes_les_jeux/por-superliga-2004-2005/")
listeSaison.append("https://www.mondefootball.fr/toutes_les_jeux/por-superliga-2005-2006/")
listeSaison.append("https://www.mondefootball.fr/toutes_les_jeux/por-superliga-2006-2007/")
listeSaison.append("https://www.mondefootball.fr/toutes_les_jeux/por-superliga-2007-2008/")
listeSaison.append("https://www.mondefootball.fr/toutes_les_jeux/por-superliga-2008-2009/")
listeSaison.append("https://www.mondefootball.fr/toutes_les_jeux/por-liga-sagres-2009-2010/")
listeSaison.append("https://www.mondefootball.fr/toutes_les_jeux/por-liga-sagres-2010-2011/")
listeSaison.append("https://www.mondefootball.fr/toutes_les_jeux/por-liga-zon-sagres-2011-2012/")
listeSaison.append("https://www.mondefootball.fr/toutes_les_jeux/por-liga-zon-sagres-2012-2013/")

# FONCTIONS 

def convertiScore(score1, score2):
	score1, score2 = max(score1, score2), min(score1, score2)
	init = (score1, score2)
	if score1 == score2:
		return [0.5, 0, init]
	else:
		i = 1
		while score1 > score2 + i and score2 > 0:
			score1 -= i
			score2 -= 1
			i += 1
		return [score1 / (score1 + score2), score1, i, init]

def normaliseScore(score, lieu):
	if score[0] == score[1]:
		return 0.5
	else:
		fichier = open("data/liste_score.txt", 'r')
		txt = list(map(lambda s: s.replace("\n", '').split(" | "), fichier.readlines()))
		txtScore = list(map(lambda l: l[0], txt))
		txtFloat = list(map(lambda l: float(l[1]), txt))
		index = txtScore.index(str(convertiScore(score[0], score[1])))
		fichier.close()
		if (score[0] > score[1] and lieu == 'domicile') or (score[0] < score[1] and lieu == 'extérieur'):
			return 0.5 * (1 + txtFloat[index])
		else:
			return 0.5 * (1 - txtFloat[index])

def normaliseMoyBut(moy, ligne):
	fichier = open("data/moy_but.txt", 'r')
	txt = fichier.readlines()[ligne].replace('\n', '').split(" | ")
	return 1 / (1 + exp(- 4.6 / (float(txt[1]) - float(txt[0])) * (moy - float(txt[0]))))

# ALGORITHME RÉCUPÉRATIO adversaire 

listeScore = []
listeResultatEquipe = []
listeClassementEquipe = []
listeClassementEquipe_D = []
listeClassementEquipe_E = []
listeMoyBut_M = []
listeMoyBut_E = []
listeMoyBut_M_D = []
listeMoyBut_E_D = []
listeMoyBut_M_E = []
listeMoyBut_E_E = []
listeMoyBut_M_1M = []
listeMoyBut_E_1M = []
listeMoyBut_M_2M = []
listeMoyBut_E_2M = []
moyBut = 0
moyBut_D = 0
moyBut_Ex = 0
moyBut_1M = 0
moyBut_2M = 0
max_moyBut_M = 0
max_moyBut_E = 0
max_moyBut_M_D = 0
max_moyBut_E_D = 0
max_moyBut_M_E = 0
max_moyBut_E_E = 0
max_moyBut_M_1M = 0
max_moyBut_M_2M = 0
max_moyBut_E_1M = 0
max_moyBut_E_2M = 0
for saison in tqdm(listeSaison):
	soup = BeautifulSoup(requests.get(saison).content, features="html.parser")
	tableau = soup.find("table", {"class" : "standard_tabelle"})
		# tableau := tableau contenant tous les matchs
	nombreJournee = len(tableau.find_all("th"))
	nombreEquipe = int(nombreJournee / 2) + 1
	lignes = tableau.find_all("tr")
		# lignes := tableau contenant chaque ligne

	resultatEquipe = {}
	classementEquipe = {}
	classementEquipe_D = {}
	classementEquipe_E = {}
	moyBut_M = {}
	moyBut_E = {}
	moyBut_M_D = {}
	moyBut_E_D = {}
	moyBut_M_E = {}
	moyBut_E_E = {}
	moyBut_M_1M = {}
	moyBut_E_1M = {}
	moyBut_M_2M = {}
	moyBut_E_2M = {}
	for i in range(1, int(nombreEquipe / 2 + 1)):
		resultatEquipe[lignes[i].find_all("td")[2].find("a").contents[0]] = []
		resultatEquipe[lignes[i].find_all("td")[4].find("a").contents[0]] = []
		classementEquipe[lignes[i].find_all("td")[2].find("a").contents[0]] = []
		classementEquipe[lignes[i].find_all("td")[4].find("a").contents[0]] = []
		classementEquipe_D[lignes[i].find_all("td")[2].find("a").contents[0]] = []
		classementEquipe_D[lignes[i].find_all("td")[4].find("a").contents[0]] = []
		classementEquipe_E[lignes[i].find_all("td")[2].find("a").contents[0]] = []
		classementEquipe_E[lignes[i].find_all("td")[4].find("a").contents[0]] = []
		moyBut_M[lignes[i].find_all("td")[2].find("a").contents[0]] = []
		moyBut_M[lignes[i].find_all("td")[4].find("a").contents[0]] = []
		moyBut_E[lignes[i].find_all("td")[2].find("a").contents[0]] = []
		moyBut_E[lignes[i].find_all("td")[4].find("a").contents[0]] = []
		moyBut_M_D[lignes[i].find_all("td")[2].find("a").contents[0]] = []
		moyBut_M_D[lignes[i].find_all("td")[4].find("a").contents[0]] = []
		moyBut_E_D[lignes[i].find_all("td")[2].find("a").contents[0]] = []
		moyBut_E_D[lignes[i].find_all("td")[4].find("a").contents[0]] = []
		moyBut_M_E[lignes[i].find_all("td")[2].find("a").contents[0]] = []
		moyBut_M_E[lignes[i].find_all("td")[4].find("a").contents[0]] = []
		moyBut_E_E[lignes[i].find_all("td")[2].find("a").contents[0]] = []
		moyBut_E_E[lignes[i].find_all("td")[4].find("a").contents[0]] = []
		moyBut_M_1M[lignes[i].find_all("td")[2].find("a").contents[0]] = []
		moyBut_M_1M[lignes[i].find_all("td")[4].find("a").contents[0]] = []
		moyBut_E_1M[lignes[i].find_all("td")[2].find("a").contents[0]] = []
		moyBut_E_1M[lignes[i].find_all("td")[4].find("a").contents[0]] = []
		moyBut_M_2M[lignes[i].find_all("td")[2].find("a").contents[0]] = []
		moyBut_M_2M[lignes[i].find_all("td")[4].find("a").contents[0]] = []
		moyBut_E_2M[lignes[i].find_all("td")[2].find("a").contents[0]] = []
		moyBut_E_2M[lignes[i].find_all("td")[4].find("a").contents[0]] = []
	
	for numJournee in range(nombreEquipe * 2 - 2): # Chaque journée
		for i in range(int(nombreEquipe / 2 + 1) * numJournee + 1, int(nombreEquipe / 2 + 1) * (1 + numJournee)): # Chaque match

			# TXT POUR LES STATS
			score = lignes[i].find_all("td")[5]
			if score.find("a") == None:
				score = score.contents[0]
			else:
				score = score.find("a").contents[0]
			score = score.split(' ')
			score[0] = score[0].split(':')
			score[1] = score[1][1:-1].split(':')
			if len(score[1]) != 2 or len(score[0]) != 2:
				score[1] = score[0]
			score = list(map(lambda x: list(map(lambda y: int(y), x)), score[:2]))
			score.append([score[0][0] - score[1][0], score[0][1] - score[1][1]])
			moyBut += score[0][0] + score[0][1]
			moyBut_D += score[0][0]
			moyBut_Ex += score[0][1]
			moyBut_1M += score[1][0] + score[1][1]
			moyBut_2M += score[2][0] + score[2][1]
			listeScore.append(convertiScore(score[0][0], score[0][1]))

			# RESULTAT ET CLASSEMENT ET MOY_BUT EQUIPE
			resultatEquipe[lignes[i].find_all("td")[2].find("a").contents[0]].append(["domicile", score, lignes[i].find_all("td")[4].find("a").contents[0]])
			resultatEquipe[lignes[i].find_all("td")[4].find("a").contents[0]].append(["extérieur", score, lignes[i].find_all("td")[2].find("a").contents[0]])
			if numJournee > 0:
				classementEquipe[lignes[i].find_all("td")[2].find("a").contents[0]].append((classementEquipe[lignes[i].find_all("td")[2].find("a").contents[0]][-1] * numJournee + (int(score[0][0] > score[0][1]) + int(score[0][0] >= score[0][1])) / 2) / (numJournee + 1))
				classementEquipe[lignes[i].find_all("td")[4].find("a").contents[0]].append((classementEquipe[lignes[i].find_all("td")[4].find("a").contents[0]][-1] * numJournee + (int(score[0][0] < score[0][1]) + int(score[0][0] <= score[0][1])) / 2) / (numJournee + 1))
				classementEquipe_D[lignes[i].find_all("td")[2].find("a").contents[0]].append([(classementEquipe_D[lignes[i].find_all("td")[2].find("a").contents[0]][-1][0] * classementEquipe_D[lignes[i].find_all("td")[2].find("a").contents[0]][-1][1] + (int(score[0][0] > score[0][1]) + int(score[0][0] >= score[0][1])) / 2) / (classementEquipe_D[lignes[i].find_all("td")[2].find("a").contents[0]][-1][1] + 1), classementEquipe_D[lignes[i].find_all("td")[2].find("a").contents[0]][-1][1] + 1])
				classementEquipe_D[lignes[i].find_all("td")[4].find("a").contents[0]].append(classementEquipe_D[lignes[i].find_all("td")[4].find("a").contents[0]][-1])
				classementEquipe_E[lignes[i].find_all("td")[4].find("a").contents[0]].append([(classementEquipe_E[lignes[i].find_all("td")[4].find("a").contents[0]][-1][0] * classementEquipe_E[lignes[i].find_all("td")[4].find("a").contents[0]][-1][1] + (int(score[0][0] < score[0][1]) + int(score[0][0] <= score[0][1])) / 2) / (classementEquipe_E[lignes[i].find_all("td")[4].find("a").contents[0]][-1][1] + 1), classementEquipe_E[lignes[i].find_all("td")[4].find("a").contents[0]][-1][1] + 1])
				classementEquipe_E[lignes[i].find_all("td")[2].find("a").contents[0]].append(classementEquipe_E[lignes[i].find_all("td")[2].find("a").contents[0]][-1])
				moyBut_M[lignes[i].find_all("td")[2].find("a").contents[0]].append((moyBut_M[lignes[i].find_all("td")[2].find("a").contents[0]][-1] * numJournee + score[0][0]) / (numJournee + 1))
				moyBut_M[lignes[i].find_all("td")[4].find("a").contents[0]].append((moyBut_M[lignes[i].find_all("td")[4].find("a").contents[0]][-1] * numJournee + score[0][1]) / (numJournee + 1))
				moyBut_E[lignes[i].find_all("td")[2].find("a").contents[0]].append((moyBut_E[lignes[i].find_all("td")[2].find("a").contents[0]][-1] * numJournee + score[0][1]) / (numJournee + 1))
				moyBut_E[lignes[i].find_all("td")[4].find("a").contents[0]].append((moyBut_E[lignes[i].find_all("td")[4].find("a").contents[0]][-1] * numJournee + score[0][0]) / (numJournee + 1))
				moyBut_M_D[lignes[i].find_all("td")[2].find("a").contents[0]].append([(moyBut_M_D[lignes[i].find_all("td")[2].find("a").contents[0]][-1][0] * moyBut_M_D[lignes[i].find_all("td")[2].find("a").contents[0]][-1][1] + score[0][0]) / (moyBut_M_D[lignes[i].find_all("td")[2].find("a").contents[0]][-1][1] + 1), moyBut_M_D[lignes[i].find_all("td")[2].find("a").contents[0]][-1][1] + 1])
				moyBut_M_D[lignes[i].find_all("td")[4].find("a").contents[0]].append(moyBut_M_D[lignes[i].find_all("td")[4].find("a").contents[0]][-1])
				moyBut_M_E[lignes[i].find_all("td")[2].find("a").contents[0]].append(moyBut_M_E[lignes[i].find_all("td")[2].find("a").contents[0]][-1])
				moyBut_M_E[lignes[i].find_all("td")[4].find("a").contents[0]].append([(moyBut_M_E[lignes[i].find_all("td")[4].find("a").contents[0]][-1][0] * moyBut_M_E[lignes[i].find_all("td")[4].find("a").contents[0]][-1][1] + score[0][1]) / (moyBut_M_E[lignes[i].find_all("td")[4].find("a").contents[0]][-1][1] + 1), moyBut_M_E[lignes[i].find_all("td")[4].find("a").contents[0]][-1][1] + 1])
				moyBut_E_D[lignes[i].find_all("td")[2].find("a").contents[0]].append([(moyBut_E_D[lignes[i].find_all("td")[2].find("a").contents[0]][-1][0] * moyBut_E_D[lignes[i].find_all("td")[2].find("a").contents[0]][-1][1] + score[0][1]) / (moyBut_E_D[lignes[i].find_all("td")[2].find("a").contents[0]][-1][1] + 1), moyBut_E_D[lignes[i].find_all("td")[2].find("a").contents[0]][-1][1] + 1])
				moyBut_E_D[lignes[i].find_all("td")[4].find("a").contents[0]].append(moyBut_E_D[lignes[i].find_all("td")[4].find("a").contents[0]][-1])
				moyBut_E_E[lignes[i].find_all("td")[2].find("a").contents[0]].append(moyBut_E_E[lignes[i].find_all("td")[2].find("a").contents[0]][-1])
				moyBut_E_E[lignes[i].find_all("td")[4].find("a").contents[0]].append([(moyBut_E_E[lignes[i].find_all("td")[4].find("a").contents[0]][-1][0] * moyBut_E_E[lignes[i].find_all("td")[4].find("a").contents[0]][-1][1] + score[0][0]) / (moyBut_E_E[lignes[i].find_all("td")[4].find("a").contents[0]][-1][1] + 1), moyBut_E_E[lignes[i].find_all("td")[4].find("a").contents[0]][-1][1] + 1])
				moyBut_M_1M[lignes[i].find_all("td")[2].find("a").contents[0]].append((moyBut_M_1M[lignes[i].find_all("td")[2].find("a").contents[0]][-1] * numJournee + score[1][0]) / (numJournee + 1))
				moyBut_M_1M[lignes[i].find_all("td")[4].find("a").contents[0]].append((moyBut_M_1M[lignes[i].find_all("td")[4].find("a").contents[0]][-1] * numJournee + score[1][1]) / (numJournee + 1))
				moyBut_E_1M[lignes[i].find_all("td")[2].find("a").contents[0]].append((moyBut_E_1M[lignes[i].find_all("td")[2].find("a").contents[0]][-1] * numJournee + score[1][1]) / (numJournee + 1))
				moyBut_E_1M[lignes[i].find_all("td")[4].find("a").contents[0]].append((moyBut_E_1M[lignes[i].find_all("td")[4].find("a").contents[0]][-1] * numJournee + score[1][0]) / (numJournee + 1))
				moyBut_M_2M[lignes[i].find_all("td")[2].find("a").contents[0]].append((moyBut_M_2M[lignes[i].find_all("td")[2].find("a").contents[0]][-1] * numJournee + score[2][0]) / (numJournee + 1))
				moyBut_M_2M[lignes[i].find_all("td")[4].find("a").contents[0]].append((moyBut_M_2M[lignes[i].find_all("td")[4].find("a").contents[0]][-1] * numJournee + score[2][1]) / (numJournee + 1))
				moyBut_E_2M[lignes[i].find_all("td")[2].find("a").contents[0]].append((moyBut_E_2M[lignes[i].find_all("td")[2].find("a").contents[0]][-1] * numJournee + score[2][1]) / (numJournee + 1))
				moyBut_E_2M[lignes[i].find_all("td")[4].find("a").contents[0]].append((moyBut_E_2M[lignes[i].find_all("td")[4].find("a").contents[0]][-1] * numJournee + score[2][0]) / (numJournee + 1))
			else:
				classementEquipe[lignes[i].find_all("td")[2].find("a").contents[0]].append((int(score[0][0] > score[0][1]) + int(score[0][0] >= score[0][1])) / 2)
				classementEquipe[lignes[i].find_all("td")[4].find("a").contents[0]].append((int(score[0][0] < score[0][1]) + int(score[0][0] <= score[0][1])) / 2)
				classementEquipe_D[lignes[i].find_all("td")[2].find("a").contents[0]].append([(int(score[0][0] > score[0][1]) + int(score[0][0] >= score[0][1])) / 2, 1])
				classementEquipe_E[lignes[i].find_all("td")[4].find("a").contents[0]].append([(int(score[0][0] < score[0][1]) + int(score[0][0] <= score[0][1])) / 2, 1])
				classementEquipe_D[lignes[i].find_all("td")[4].find("a").contents[0]].append([0, 0])
				classementEquipe_E[lignes[i].find_all("td")[2].find("a").contents[0]].append([0, 0])
				moyBut_M[lignes[i].find_all("td")[2].find("a").contents[0]].append(score[0][0])
				moyBut_M[lignes[i].find_all("td")[4].find("a").contents[0]].append(score[0][1])
				moyBut_E[lignes[i].find_all("td")[2].find("a").contents[0]].append(score[0][1])
				moyBut_E[lignes[i].find_all("td")[4].find("a").contents[0]].append(score[0][0])
				moyBut_M_D[lignes[i].find_all("td")[2].find("a").contents[0]].append([score[0][0], 1])
				moyBut_M_D[lignes[i].find_all("td")[4].find("a").contents[0]].append([0, 0])
				moyBut_M_E[lignes[i].find_all("td")[2].find("a").contents[0]].append([0, 0])
				moyBut_M_E[lignes[i].find_all("td")[4].find("a").contents[0]].append([score[0][1], 1])
				moyBut_E_D[lignes[i].find_all("td")[2].find("a").contents[0]].append([score[0][1], 1])
				moyBut_E_D[lignes[i].find_all("td")[4].find("a").contents[0]].append([0, 0])
				moyBut_E_E[lignes[i].find_all("td")[2].find("a").contents[0]].append([0, 0])
				moyBut_E_E[lignes[i].find_all("td")[4].find("a").contents[0]].append([score[1][0], 1])
				moyBut_M_1M[lignes[i].find_all("td")[2].find("a").contents[0]].append(score[1][0])
				moyBut_M_1M[lignes[i].find_all("td")[4].find("a").contents[0]].append(score[1][1])
				moyBut_E_1M[lignes[i].find_all("td")[2].find("a").contents[0]].append(score[1][1])
				moyBut_E_1M[lignes[i].find_all("td")[4].find("a").contents[0]].append(score[1][0])
				moyBut_M_2M[lignes[i].find_all("td")[2].find("a").contents[0]].append(score[2][0])
				moyBut_M_2M[lignes[i].find_all("td")[4].find("a").contents[0]].append(score[2][1])
				moyBut_E_2M[lignes[i].find_all("td")[2].find("a").contents[0]].append(score[2][1])
				moyBut_E_2M[lignes[i].find_all("td")[4].find("a").contents[0]].append(score[2][0])
	for equipe in moyBut_M.keys():
		if moyBut_M[equipe][-1] > max_moyBut_M:
			max_moyBut_M = moyBut_M[equipe][-1]
		if moyBut_E[equipe][-1] > max_moyBut_E:
			max_moyBut_E = moyBut_E[equipe][-1]
		if moyBut_M_D[equipe][-1][0] > max_moyBut_M_D:
			max_moyBut_M_D = moyBut_M_D[equipe][-1][0]
		if moyBut_E_D[equipe][-1][0] > max_moyBut_E_D:
			max_moyBut_E_D = moyBut_E_D[equipe][-1][0]
		if moyBut_M_E[equipe][-1][0] > max_moyBut_M_E:
			max_moyBut_M_E = moyBut_M_E[equipe][-1][0]
		if moyBut_E_E[equipe][-1][0] > max_moyBut_E_E:
			max_moyBut_E_E = moyBut_E_E[equipe][-1][0]
		if moyBut_M_1M[equipe][-1] > max_moyBut_M_1M:
			max_moyBut_M_1M = moyBut_M_1M[equipe][-1]
		if moyBut_E_1M[equipe][-1] > max_moyBut_E_1M:
			max_moyBut_E_1M = moyBut_E_1M[equipe][-1]
		if moyBut_M_2M[equipe][-1] > max_moyBut_M_2M:
			max_moyBut_M_2M = moyBut_M_2M[equipe][-1]
		if moyBut_E_2M[equipe][-1] > max_moyBut_E_2M:
			max_moyBut_E_2M = moyBut_E_2M[equipe][-1]
	listeResultatEquipe.append(resultatEquipe)
	listeClassementEquipe.append(classementEquipe)
	listeClassementEquipe_D.append(classementEquipe_D)
	listeClassementEquipe_E.append(classementEquipe_E)
	listeMoyBut_M.append(moyBut_M)
	listeMoyBut_E.append(moyBut_E)
	listeMoyBut_M_D.append(moyBut_M_D)
	listeMoyBut_E_D.append(moyBut_E_D)
	listeMoyBut_M_E.append(moyBut_M_E)
	listeMoyBut_E_E.append(moyBut_E_E)
	listeMoyBut_M_1M.append(moyBut_M_1M)
	listeMoyBut_E_1M.append(moyBut_E_1M)
	listeMoyBut_M_2M.append(moyBut_M_2M)
	listeMoyBut_E_2M.append(moyBut_E_2M)

listeScore.sort(key=lambda l: [-l[0], -l[1], l[2], -l[-1][0]])
temp = listeScore[0][-1]

fichier_listeScore = open("data/liste_score.txt", 'w')
index = 0
for i in range(1, len(listeScore)):
	if listeScore[i][-1] != temp:
		fichier_listeScore.write(str(listeScore[i - 1]) + " | " + str(1 - 0.5 * (i + index) / len(listeScore)) + '\n')
		temp = listeScore[i][-1]
		index = i
fichier_listeScore.write(str(listeScore[-1]) + " | " + str(1 - 0.5 * (len(listeScore) + index) / len(listeScore)) + '\n')
fichier_listeScore.close()

moyBut /= len(listeScore) * 2
moyBut_D /= len(listeScore)
moyBut_Ex /= len(listeScore)
moyBut_1M /= len(listeScore) * 2
moyBut_2M /= len(listeScore) * 2
fichier_moyBut = open("data/moy_but.txt", 'w')
fichier_moyBut.write(str(moyBut) + " | " + str(max_moyBut_M) + '\n')
fichier_moyBut.write(str(moyBut) + " | " + str(max_moyBut_E) + '\n')
fichier_moyBut.write(str(moyBut_D) + " | " + str(max_moyBut_M_D) + '\n')
fichier_moyBut.write(str(moyBut_D) + " | " + str(max_moyBut_E_E) + '\n')
fichier_moyBut.write(str(moyBut_Ex) + " | " + str(max_moyBut_E_D) + '\n')
fichier_moyBut.write(str(moyBut_Ex) + " | " + str(max_moyBut_M_E) + '\n')
fichier_moyBut.write(str(moyBut_1M) + " | " + str(max_moyBut_M_1M) + '\n')
fichier_moyBut.write(str(moyBut_1M) + " | " + str(max_moyBut_E_1M) + '\n')
fichier_moyBut.write(str(moyBut_2M) + " | " + str(max_moyBut_M_2M) + '\n')
fichier_moyBut.write(str(moyBut_2M) + " | " + str(max_moyBut_E_2M) + '\n')
fichier_moyBut.close()

# ALGORITHME ÉCRITURE ENTRÉE

"""
51 neuronnes d'entrées :

- ÉQUIPE A (domicile) :
	- match journ n-5 :
		● score (normalisé)
		● ratio adversaire V/N/D (au jour n-1)
		● domicile (1) ou extérieur (0)
	- match journ n-4 :
		● score (normalisé)
		● ratio adversaire V/N/D (au jour n-1)
		● domicile (1) ou extérieur (0)
	- match journ n-3 :
		● score (normalisé)
		● ratio adversaire V/N/D (au jour n-1)
		● domicile (1) ou extérieur (0)
	- match journ n-2 :
		● score (normalisé)
		● ratio adversaire V/N/D (au jour n-1)
		● domicile (1) ou extérieur (0)
	- match journ n-1 :
		● score (normalisé)
		● ratio adversaire V/N/D (au jour n-1)
		● domicile (1) ou extérieur (0)
	- données globales :
		● nombre de buts mis moyen (normalisé)
		● nombre de buts pris moyen (normalisé)
		● nombre de buts mis à domicile (normalisé)
		● nombre de buts pris à domicile (normalisé)
		● nombre de buts mis moyen 1ère mi-temps (normalisé)
		● nombre de buts pris moyen 1ère mi-temps (normalisé)
		● nombre de buts mis moyen 2ème mi-temps (normalisé)
		● nombre de buts pris moyen 2ème mi-temps (normalisé)
		● ratio V/N/D (au jour n-1)
		● ratio V/N/D à domicile (au jour n-1)

- INFO MATCH :
	- info match :
		● journée n (normalisée)

- ÉQUIPE B (extérieure) :
	- match journ n-5 :
		● score (normalisé)
		● ratio adversaire V/N/D (au jour n-1)
		● domicile (1) ou extérieur (0)
	- match journ n-4 :
		● score (normalisé)
		● ratio adversaire V/N/D (au jour n-1)
		● domicile (1) ou extérieur (0)
	- match journ n-3 :
		● score (normalisé)
		● ratio adversaire V/N/D (au jour n-1)
		● domicile (1) ou extérieur (0)
	- match journ n-2 :
		● score (normalisé)
		● ratio adversaire V/N/D (au jour n-1)
		● domicile (1) ou extérieur (0)
	- match journ n-1 :
		● score (normalisé)
		● ratio adversaire V/N/D (au jour n-1)
		● domicile (1) ou extérieur (0)
	- données globales :
		● nombre de buts mis moyen (normalisé)
		● nombre de buts pris moyen (normalisé)
		● nombre de buts mis à l'extérieur (normalisé)
		● nombre de buts pris à l'extérieur (normalisé)
		● nombre de buts mis moyen 1ère mi-temps (normalisé)
		● nombre de buts pris moyen 1ère mi-temps (normalisé)
		● nombre de buts mis moyen 2ème mi-temps (normalisé)
		● nombre de buts pris moyen 2ème mi-temps (normalisé)
		● ratio V/N/D (au jour n-1)
		● ratio V/N/D à l'extérieur (au jour n-1)
"""

listeEntree = []
listeSortie = [] # 0 = victoire | 1 = nul | 2 = défaite
for saison in tqdm(listeResultatEquipe): # Chaque dictionnaire représentant chaque saison
	classementEquipe = listeClassementEquipe[listeResultatEquipe.index(saison)]
	classementEquipe_D = listeClassementEquipe_D[listeResultatEquipe.index(saison)]
	classementEquipe_E = listeClassementEquipe_E[listeResultatEquipe.index(saison)]
	moyBut_M = listeMoyBut_M[listeResultatEquipe.index(saison)]
	moyBut_E = listeMoyBut_E[listeResultatEquipe.index(saison)]
	moyBut_M_D = listeMoyBut_M_D[listeResultatEquipe.index(saison)]
	moyBut_M_E = listeMoyBut_M_E[listeResultatEquipe.index(saison)]
	moyBut_E_D = listeMoyBut_E_D[listeResultatEquipe.index(saison)]
	moyBut_E_E = listeMoyBut_E_E[listeResultatEquipe.index(saison)]
	moyBut_M_1M = listeMoyBut_M_1M[listeResultatEquipe.index(saison)]
	moyBut_E_1M = listeMoyBut_E_1M[listeResultatEquipe.index(saison)]
	moyBut_M_2M = listeMoyBut_M_2M[listeResultatEquipe.index(saison)]
	moyBut_E_2M = listeMoyBut_E_2M[listeResultatEquipe.index(saison)]
	for club in saison.keys(): # Chaque équipe (clés des dictionaires)
		for numJournee in range(5, len(saison[club])): # Chaque match joué par cette équipe dans cette saison
			match = saison[club][numJournee] # On ne considère par les 5 premiers matchs
			if match[0] == 'domicile': # On s'en fout de si le match est à l'extérieur (on regardera l'autre équipe après)
				entree = []

				equipe = club
				for i in range(5, 0, -1):
					entree.append(normaliseScore(saison[equipe][numJournee - i][1][0], saison[equipe][numJournee - i][0]))
					equipeAdverse = saison[equipe][numJournee - i][2]
					entree.append(classementEquipe[equipeAdverse][numJournee - 1])
					entree.append(int(saison[equipe][numJournee - i][0] == 'domicile'))
				entree.append(normaliseMoyBut(moyBut_M[equipe][numJournee - 1], 0))
				entree.append(normaliseMoyBut(moyBut_E[equipe][numJournee - 1], 1))
				entree.append(normaliseMoyBut(moyBut_M_D[equipe][numJournee - 1][0], 2))
				entree.append(normaliseMoyBut(moyBut_E_D[equipe][numJournee - 1][0], 4))
				entree.append(normaliseMoyBut(moyBut_M_1M[equipe][numJournee - 1], 6))
				entree.append(normaliseMoyBut(moyBut_E_1M[equipe][numJournee - 1], 7))
				entree.append(normaliseMoyBut(moyBut_M_2M[equipe][numJournee - 1], 8))
				entree.append(normaliseMoyBut(moyBut_E_2M[equipe][numJournee - 1], 9))
				entree.append(classementEquipe[equipe][numJournee - 1])
				entree.append(classementEquipe_D[equipe][numJournee - 1][0])

				entree.append(numJournee / (len(saison[equipe]) - 1))

				equipe = match[2]
				for i in range(5, 0, -1):
					entree.append(normaliseScore(saison[equipe][numJournee - i][1][0], saison[equipe][numJournee - i][0]))
					equipeAdverse = saison[equipe][numJournee - i][2]
					entree.append(classementEquipe[equipeAdverse][numJournee - 1])
					entree.append(int(saison[equipe][numJournee - i][0] == 'domicile'))
				entree.append(normaliseMoyBut(moyBut_M[equipe][numJournee - 1], 0))
				entree.append(normaliseMoyBut(moyBut_E[equipe][numJournee - 1], 1))
				entree.append(normaliseMoyBut(moyBut_M_E[equipe][numJournee - 1][0], 5))
				entree.append(normaliseMoyBut(moyBut_E_E[equipe][numJournee - 1][0], 3))
				entree.append(normaliseMoyBut(moyBut_M_1M[equipe][numJournee - 1], 6))
				entree.append(normaliseMoyBut(moyBut_E_1M[equipe][numJournee - 1], 7))
				entree.append(normaliseMoyBut(moyBut_M_2M[equipe][numJournee - 1], 8))
				entree.append(normaliseMoyBut(moyBut_E_2M[equipe][numJournee - 1], 9))
				entree.append(classementEquipe[equipe][numJournee - 1])
				entree.append(classementEquipe_E[equipe][numJournee - 1][0])

				for i in range(len(entree)):
					if entree[i] < 1e-4:
						entree[i] = 0
					elif entree[i] > 1:
						entree[i] = 1
				listeEntree.append(entree)

				listeSortie.append(int(match[1][0][0] < match[1][0][1]) + int(match[1][0][0] <= match[1][0][1]))

fichier_e = open("data/tous_les_matchs.txt", 'w')
fichier_s = open("data/tous_les_resultats.txt", 'w')
fichier_nb = open("data/nbMatchs.txt", 'w')
for entree in tqdm(listeEntree):
	for parametre in entree[:-1]:
		fichier_e.write(str(parametre) + ',')
	fichier_e.write(str(entree[-1]) + '\n')
for sortie in listeSortie:
	fichier_s.write(str(sortie) + '\n')
fichier_nb.write(str(len(listeEntree)) + '\n')

print("Au total, " + str(len(listeEntree)) + " matchs d'entraînement seront utilisés !")
fichier_nb.close()
fichier_e.close()
fichier_s.close()